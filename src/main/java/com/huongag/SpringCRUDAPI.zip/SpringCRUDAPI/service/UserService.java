package com.huongag.SpringCRUDAPI.service;


import com.huongag.SpringCRUDAPI.model.Users;

public interface UserService {
    void addUser(Users user);

    Users updateUser(int id, Users user);
}

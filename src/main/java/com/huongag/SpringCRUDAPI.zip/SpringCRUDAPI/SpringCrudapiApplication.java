package com.huongag.SpringCRUDAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCrudapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCrudapiApplication.class, args);
		System.out.println("Running SpringCRUD");
	}

}

package com.huongag.SpringCRUDAPI.controller;

import com.huongag.SpringCRUDAPI.model.Users;
import com.huongag.SpringCRUDAPI.service.impl.UserServiceImpl;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
//@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserServiceImpl userService;

    @PostMapping("/add/user")
    public String addUser(@RequestBody Users user) {
        userService.addUser(user);
        return "Create Success";
    }

    @GetMapping("/user")
    public List<Users> user() {
        return userService.getUsers();
    }

    @PutMapping("/user/{id}")
    public ResponseEntity<String> updateUser(@PathVariable("id") int id, @RequestBody Users user) {
        Users user1 = null;
        try {
            user1 = userService.updateUser(id, user);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to update", HttpStatus.BAD_REQUEST);
        }
        if (user1 != null) {
            return new ResponseEntity<>("Updated!", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Failed to update!", HttpStatus.BAD_REQUEST);
        }
    }
    
}
